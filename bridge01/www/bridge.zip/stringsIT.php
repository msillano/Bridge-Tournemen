<?php   
  include_once("$d/common_use.php");  
      
// =========================== startup 	 
// do not change this
 $idTorn = ( array_key_exists('idTorn', $_GET))? $_GET['idTorn']: sqlValue("SELECT MAX(ID_tor) FROM torneo");
 ;    
 $idTorn = ( array_key_exists('idTorn', $_POST))? $_POST['idTorn']: $idTorn;                    
 $torneo =  sqlValue("SELECT descrizione FROM torneo WHERE ID_tor = $idTorn");     
 $buttonName = 'user'; 						 
 $user='';	   
 if(isset($_COOKIE['user']))
 	  $user=  $_COOKIE['user'];

// ============================= translate section			 
// ============================= italiano 
 $suit =  array('F','Q','C','P','SA');
 $positon= array('N','E','S','O'); 
 $ns = 'NS';
 $eo = 'EO';
 $title ='Torneo di Bridge';
 
 $button000 = 'vai Inizio';
 $button101 = 'Risultati globali';
 $button102 = 'Precedenti';
 $button103 = 'Nuova giornata';   
 $button104 = 'Giocatori';    
 $button106 = 'Documenti';    
 $button110 = 'log in';      
 $button201 = 'calcola';
 $button202 = 'Risultati';
 $button203 = 'accetta';
 $button204 = 'ruota';
 $button301 = 'Risultati';    
 $button401 = 'Elenco partite';    
 $button402 = 'Set risultati';    
 $button501 = 'Elenco partite';    
 $button502 = 'Totali giornata';    
 $button601 = 'Risultati pregressi';    
 $button602 = 'salva';    
 $button701 = 'salva';    
 $button702 = 'Risultati globali';
 $button801 = 'Cancella DBase'; 
 $button901 = 'Invio email';
 $tip101    = 'Per iniziare una giornata';
 $tip102    = 'Per consultare le giornate precedenti';
 $tip103    = 'Per vedere i risultati dei giocatori del torneo';	
 $tip104    = 'Scegliere il torneo nella lista';
 $tip105    = 'Modificare tornei e giocatori';	
 $tip106    = 'Elenco documentazione del torneo';	
 $tip140    = 'Nickname del giocatore, max 6 lettere';
 $tip141    = 'Nome e Cognome';
 $tip142    = 'e-mail del giocatore';	
 $tip150    = 'Scelta torneo ed aggiornamenti';
 $tip151    = 'Scelta torneo';
 $tip201    = 'Definisce le coppie al tavolo';
 $tip202    = 'Trova le altre possibili combinazioni'; 
 $tip203    = 'Salva le partite indicate' ;	
 $tip300    = 'Cancella la giornata';
 $tip301    = 'Invia e-mail con i risultati' ; 
 $tip601    = 'Aggiungere giornate non registrate';	
 $tip701    = 'Salva gli score e blocca modifiche alla giornata';
 $tip801	= 'Reset, elimina tutti i dati';
 $tip811	= 'Salva, ma non ricalcola i dati delle partite gi&agrave; giocate';  
 $tip812	= 'ATTENZIONE, cancella il torneo e tutte le partite';	 
 $tip813	= 'Modificare o inserire i giocatori';
 $tip814	= 'Inserire il nome del nuovo torneo';		
 $tip901  = 'esiste gi�.';

 $msg000   = 'Tornei GioBridge';
 $msg101   = 'Edit Torneo';
 $msg102   = 'legenda:';
 $msg103   = 'HCP = Punti onori std (4 3 2 1)';
 $msg104   = 'ZHP = Punti onori Zar (6 4 2 1)';
 $msg105   =  'BP = Punti onori Banzai (5 4 3 2 1)';

$msg106   = 'DS =  Punti Duplicato standard';
$msg107   = 'IMP = International Match Points';
$msg108   = 'GBP = Punti GioBridge' ;
$msg109   = 'RMP = Russian Match Points';
$msg110   = 'EMP = Estonian Match Points';

$msg111   = 'NO = Nessuna conversione';
$msg112   = 'MP = Match Points standard';
$msg113   = 'IR = Rango invertito (5 4 3 2 1)';
$msg114   = 'F1 = Rango come F1 (10 8 6 5 4)';

$msg115   = 'TOT = Totale punteggi finale';
$msg116   = 'AVG = Media punteggi finale';
$msg150   = 'Definizione giocatori';
$msg151 = 'Una volta inseriti, i giocatori possono solo essere modificati.';
$msg152 = 'max. mani';
$msg153 = 'Una giornata, 4 o 5 giocatori';
$msg154 = 'mani';
$msg155 = 'PARTITA';
$msg156 = 'Partite del ';
$msg157 = 'contr.';
$msg158 = 'dichiara';
$msg159 = 'prese';
$msg160 = 'somme';
$msg161 = 'Mano';
$msg201 = 'Accesso come giocatore';
$msg301 = 'Le partite possono essere giocate in qualsiasi ordine.';
 $msg601  = 'Classifica giocatori.';
 $msg602  = 'TOTALE';
 $msg603  = 'PRESENZE';
 $msg604  = 'MEDIA TORNEO';
 $msg701 =  '&Egrave; possibile inserire score della giornata anche senza i risultati delle singole mani. ';
 $msg702 = '&nbsp;Piazzamenti del ';
 $msg703 = '&nbsp; Risultati del ';
 $msg812	= 'ATTENZIONE, cancella ogni torneo e tutte le partite !';	
$msg813  = 'partite';
 $msg814  = 'giornate';

 $msg902  = 'File troppo grande (max. 1M).';
 $msg903  = 'Sono ammessi solo file PBN, PDF, HTM, HTML.';
 $msg904  = 'Carica il file.';
 $msg905  = 'Descrizione indispensabile per file PDF, HTML.';
 $msg906  = 'caricato.';
 $msg907  = 'file non copiato.';
 $msg908  = 'Per inviare file ';
 $msg909  = 'Nei file PBN forza i dati della mano ';
 $msg910  = 'Invia file';
 $msg911  = 'Nome (max 40 chr.)';
$msg912  = 'Giornata';
$msg913  = 'Partite';
$msg914  = 'Risultati';

 // ============================= end translate section	
 // do not change this
 $contracts = array();
 for ($i = 1; $i <= 7; $i++) {	
    foreach($suit as $value)
      	 $contracts[] = $i.$value;
 }
?>
