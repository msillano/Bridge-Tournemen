<?php          
include_once("$d/common_use.php"); 
include_once("$d/strings_use.php"); 
					   
 //	per ruotare giocatori	(old) (5) 	
$trasla[1]=array(0, 1, 2, 3, 4, 5);
$trasla[2]=array(0, 1, 2, 3, 5, 4);
$trasla[3]=array(0, 1, 2, 4, 3, 5);
$trasla[4]=array(0, 1, 2, 4, 5, 3);
$trasla[5]=array(0, 1, 2, 5, 3, 4);
$trasla[6]=array(0, 1, 2, 5, 4, 3);
  
	
	 

// =============  bridge DB access utilities    
// dipendono da bridge.css e DB bridge
// returns the player's nickname in position 'N'|'E'|'S'|'O' 
function getGiocatoreNick($IDpartita, $posizione){
return sqlValue( "SELECT  giocatore.nickname
      FROM gioca, giocatore
	  WHERE gioca.ID_par = $IDpartita AND
	  gioca.ID_gio = giocatore.ID_gio AND
	  gioca.posizione = '$posizione'");
}                  

// returns ID_par, given day and ordine (1..n)
function getPartitaID($giorno, $ordinePartita){
global $idTorn;
return sqlValue( "SELECT  partita.ID_par
      FROM partita, giornata
	  WHERE giornata.data = '$giorno' AND
	  partita.ID_day = giornata.ID_day AND
	  giornata.ID_tor = $idTorn AND
	  partita.progressivo = $ordinePartita");
}
      
	    
// returns all progressivo, ID_par, given data day 
function getArrayPartiteID($giorno){
global $idTorn;
return sqlLookup( "SELECT  progressivo, partita.ID_par
      FROM partita, giornata
	  WHERE giornata.data = '$giorno' AND
	  partita.ID_day = giornata.ID_day AND
      giornata.ID_tor = $idTorn 
 	     ORDER BY progressivo" );
}
  
// returns position N'|'E'|'S'|'O', given partita e player
function getPosizione($IDpartita, $IDgiocatore){
return sqlValue( "SELECT  gioca.posizione
      FROM gioca
	  WHERE gioca.ID_par = $IDpartita AND
	  gioca.ID_gio = $IDgiocatore");
}		

// gets data, given ID_par      
function getData($IDpartita){ 
return sqlValue( "SELECT  giornata.data 
      FROM partita, giornata
	  WHERE partita.ID_par = $IDpartita AND
	  partita.ID_day = giornata.ID_day" );
}
 
// gets ID_day, given data    
function getIDday($giorno){ 
global $idTorn;
return sqlValue( "SELECT  ID_day
      FROM giornata
	  WHERE giornata.data = '$giorno' AND
	  giornata.ID_tor = $idTorn"); 
 
}
             
   
// get rank array (F1 like)
function rankArrayF1($punti){
   $rank = array();	   
   arsort($punti);
   reset($punti);
   $vals = array(10,8,6,5,4,3,2,1);
   $i = 0;      
   $k = 0;      
   $old = 9999;
   while (list($chiave, $valore) = each($punti)) { 
       if ($old == $valore){
          $rank[$chiave] = $vals[$k];  
          $i++;
          }
       else {  
          $k = $i;
          $rank[$chiave] = $vals[$i++]; 
          }  
      $old = $valore;
   }
   ksort($rank);
return $rank; 
}		
// get rank array (matchpoints)
function rankArrayMP($punti){  
   $rank = array();	
   $ptx =  array_values($punti);      
   while (list($chiave, $valore) = each($punti)) { 	
          $k = 0; 
		  for($i = 0; $i < count($ptx); $i++)  {    
 			  if ($valore > $ptx[$i]) $k += 2;
			  if ($valore == $ptx[$i]) $k += 1;
			  }	
// elimina il test con se stesso
          $rank[$chiave] = $k-1;  
          }
 return $rank; 
}

function rankArrayIR($punti){
   $rank = array();
   arsort($punti);
   reset($punti); 
   $vals = array(5,4,3,2,1,0,0,0);	

   $i = 0;      
   $k = 0;      
   $old = 9999;
   while (list($chiave, $valore) = each($punti)) { 
       if ($old == $valore){
          $rank[$chiave] = $vals[$k];  
          $i++;
          }
       else {  
          $k = $i;
          $rank[$chiave] = $vals[$i++]; 
          }  
      $old = $valore;
   }
   ksort($rank);
  return $rank; 
}									 

function rankArrayNO($punti){ 
 return $punti;
 }

      // torna un array di ID_gio di una giornata esistente		
function getGiocatoriIDArray($data) { 	   
global $idTorn;
return  sqlArray( "SELECT DISTINCT giocatore.ID_gio 
            FROM giocatore, gioca, partita, giornata
			WHERE  giocatore.ID_gio = gioca.ID_gio
			AND    gioca.ID_par = partita.ID_par
			AND    partita.ID_day = giornata.ID_day
			AND    giornata.data = '$data'
			AND    giornata.ID_tor = $idTorn
			ORDER BY giocatore.ID_gio;" );
}  
  		
// torna un array di ID_Gio => nicknames da un array GiocatoriIDArray	
function getNicksGio($IDGio) { 	   
$niks = array();  
 foreach($IDGio as $value){	   
	      $niks[$value] = sqlValue("SELECT nickname FROM giocatore WHERE ID_gio = $value");
	      } 
 return $niks;
 }

// torna una stringa "ns: Xxxx, Yyyy" per una partita esistente 
function getCoppia($role, $IDpartita) { 
global $ns;
global $eo;	
   $a = sqlValue("SELECT giocatore.nickname 
            FROM giocatore, gioca
			WHERE  giocatore.ID_gio = gioca.ID_gio
			AND    gioca.ID_par = $IDpartita
			AND    gioca.posizione = '".strtoupper(substr($role,0,1))."'");
   $b = sqlValue("SELECT giocatore.nickname 
            FROM giocatore, gioca
			WHERE  giocatore.ID_gio = gioca.ID_gio
			AND    gioca.ID_par = $IDpartita
			AND    gioca.posizione = '".strtoupper(substr($role,1,1))."'");
		if ($role == 'NS')
        return $ns.': '.$a.', '.$b;  
    return $eo.': '.$a.', '.$b;  
   }          
 
 function prese2text($prese) {	
	if ($prese == 0 )		  
	   return 'm.i.';
	if ($prese > 0)
	   return '+'.$prese;
	return $prese;  
}	
	   
function text2prese($text) {	
	if ($text == 'm.i.' )		  
	   return 0;
	if (substr($text, 0,1) == '+')
	   return substr($text,1,1);
	return $text;  
}	

 function makeIcoButton( $ico, $name, $value, $tip = NULL, $confirm = NULL){   	  
       $buttx =  "<button class='icobutton20' style='background-image: url($ico)' type='submit' name='$name' value='$value' ";
	   if ($tip  != NULL)    
	  			 $buttx .=	"title='$tip' ";
	   if ($confirm != NULL)
	   			 $buttx .=	'onclick="return confirm('."'$confirm'".');"  ';
    return  $buttx . " ></button> ";
    } 
	
 function makeLinkButton( $ico, $href, $tip = NULL, $confirm = NULL){   
       $buttx =  "<button class='icobutton20' style='background-image: url($ico)' type='button' ";
	   if ($tip  != NULL)    
	  			 $buttx .=	"title='$tip' ";
	   if ($confirm != NULL)
	   			 $buttx .=	'onclick="if (confirm('."'$confirm'".')) location.href='."'$href'".';"  ';	  
			else		  
				 $buttx .=	"onclick=".'"location.href='."'$href'".';" ';	  
    return  $buttx . '></button> ';
  } 
	
function makeHelpButton( $ico, $href){ 
       $buttx =	"<a href='$href' ><img 	src='$ico' align = 'absmiddle' style='margin-left: -7px'></a>";
    return  $buttx ;
  } 
	          
  function makeBigButton($text, $tip = NULL, $confirm = NULL){     
  global $buttonName;	
  	  $buttx =  "<input class='bigbutton' type='submit' name='$buttonName' value='$text' ";
	   if ($tip  != NULL)    
	  			 $buttx .=	"title='$tip' ";
	   if ($confirm != NULL)
	   			 $buttx .=	'onclick="return confirm('."'$confirm'".');"  ';
    return  $buttx . "/> ";
    }    
        
 ?>
