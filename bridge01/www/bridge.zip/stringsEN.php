<?php   
  include_once("$d/common_use.php");  
      
// =========================== startup 	 
// do not change this
 $idTorn = ( array_key_exists('idTorn', $_GET))? $_GET['idTorn']: sqlValue("SELECT MAX(ID_tor) FROM torneo");
 ;    
 $idTorn = ( array_key_exists('idTorn', $_POST))? $_POST['idTorn']: $idTorn;                    
 $torneo =  sqlValue("SELECT descrizione FROM torneo WHERE ID_tor = $idTorn");     
 $buttonName = 'user'; 						 
 $user='';	   
 if(isset($_COOKIE['user']))
 	  $user=  $_COOKIE['user'];

// ============================= translate section			 
// ============================= english 
 $suit =  array('C','D','H','S','NT');
 $positon= array('N','E','S','W'); 
 $ns = 'NS';
 $eo = 'EW';
 $title ='Bridge Tournament';
 
 $button000 = 'go Start';
 $button101 = 'Global results';
 $button102 = 'Previous';
 $button103 = 'New day';   
 $button104 = 'Players';    
 $button106 = 'Documents';    
 $button110 = 'Log in';      
 $button201 = 'Compute';
 $button202 = 'Results';
 $button203 = 'Accept';
 $button204 = 'Rotation';
 $button301 = 'Results';    
 $button401 = 'List of matches';    
 $button402 = 'Set results';    
 $button501 = 'List of matches';    
 $button502 = 'Day results';    
 $button601 = 'Extra results';    
 $button602 = 'Save';    
 $button701 = 'Save';    
 $button702 = 'Global results';
 $button801 = 'Clear DBase'; 
 $button901 = 'Send email';
 $tip101    = 'To start a day';
 $tip102    = 'To consult the previous days';
 $tip103    = 'To see the results of the tournament players';	
 $tip104    = 'Choose the tournament in the list';
 $tip105    = 'Modify tournaments and players';	
 $tip106    = 'Tournament documentation list';	
 $tip140    = 'Player nickname, max 6 letters';
 $tip141    = 'Name and surname';
 $tip150    = 'Tournament choice and updates';
 $tip151    = 'Tournament choice';
 $tip142    = 'Player email';	
 $tip201    = 'Define the couples at the table';
 $tip202    = 'Find other possible combinations'; 
 $tip203    = 'Save the indicated games' ;	
 $tip300    = 'Clear the day';
 $tip301    = 'Send email with the results' ; 
 $tip601    = 'Add unregistered days';	
 $tip701    = 'Save the scores and block changes to the day';
 $tip801	= 'Reset, delete all data';
 $tip811	= 'Save, but do not recalculate the data of the games already played';  
 $tip812	= 'ATTENTION, cancel the tournament and all matches';	 
 $tip813	= 'Change or insert players';
 $tip814	= 'Enter the name of the new tournament';
 $tip901  = 'already exists.';
 $msg000  = 'GioBridge Tournements';
 $msg101   = 'Edit Tournement';
 $msg102   = 'Code key:';
 $msg103   = 'HCP = Honor Points standard (4 3 2 1)';
 $msg104   = 'ZHP = Zar Honor Points(6 4 2 1)';
 $msg105   =  'BP = Banzai Points (5 4 3 2 1)';

$msg106   = 'DS =  Duplicate Standard points';
$msg107   = 'IMP = International Match Points';
$msg108   = 'GBP = GioBridge Points';
$msg109   = 'RMP = Russian Match Points';
$msg110   = 'EMP = Estonian Match Points';

$msg111   = 'NO = No conversion';
$msg112   = 'MP = Match Points standard';
$msg113   = 'IR = Inverted Rank (5 4 3 2 1)';
$msg114   = 'F1 = Points as for F1 (10 8 6 5 4)';

$msg115   = 'TOT = Final Score: Total';
$msg116   = 'AVG = Final Score: Average';
$msg150   = 'Edit players';
$msg151   = 'Once entered, players can only be edited.';
$msg152   = 'max. deals';
$msg153   = 'A Chicago, 4 o 5 players';
$msg154   = 'deals';
$msg155   = 'GAME';
$msg156   = 'Games of ';
$msg157   = 'bid';
$msg158   = 'declarer';
$msg159   = 'tricks';
$msg160   = 'sums';
$msg161   = 'Deal';
$msg201   = 'Login as player';
$msg301   = 'Games can be played in any order.';

 $msg601  = 'Player Ranking.';
 $msg602  = 'TOTAL';
 $msg603  = 'PRESENCES';
 $msg604  = 'TOURNEMENT AVERAGE';
 $msg701 =  'it is possible to insert the day\'s score even without the results of the individual hands.';
 $msg702 = '&nbsp;Placements of'; 
 $msg703 = '&nbsp;Results of';
 $msg812	= 'WARNING, cancel all tournaments and all matches';	 
 $msg813  = 'games';
$msg814  = 'days';
 $msg902  = 'Your file is too large (max. 1M).';
 $msg903  = 'Only PBN, PDF, HTM, HTML files are allowed.';
 $msg904  = 'Upload file.';
 $msg905  = 'Description required for PDF, HTML files.';
 $msg906  = 'has been uploaded.';
 $msg907  = 'copying file.';
 $msg908  = 'To send file ';
 $msg909  = 'PBN files: players and hand data are updated ';
 $msg910  = 'Send file';
 $msg911  = 'Name (max 40 chr.)';
$msg912  = 'Day';
$msg913  = 'Games';
$msg914  = 'Results';
// ============================= end translate section	
 // do not change this
 $contracts = array();
 for ($i = 1; $i <= 7; $i++) {	
    foreach($suit as $value)
      	 $contracts[] = $i.$value;
 }
?>
