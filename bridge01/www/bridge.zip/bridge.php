<?php                 
/* 
bridge scores functions
*/
include_once("$d/strings_use.php");   
/*   DS vs IMP
   0 - 10   0
  20 - 40   1
  50 - 80   2
  90 - 120  3
 130 - 160  4
 170 - 210  5
 220 - 260  6
 270 - 310  7
 320 - 360  8
 370 - 420  9
 430 - 490  10
 500 - 590  11
 600 - 740  12
 750 - 890  13
 900 - 1090 14
1100 - 1290 15
1300 - 1490 16
1500 - 1740 17
1750 - 1990 18
2000 - 2240 19
2250 - 2490 20
2500 - 2990 21
3000 - 3490 22
3500 - 3990 23
4000 o pi�  24
*/

$puntiIMP=array(10, 40, 80, 120, 160, 210, 260, 310, 360, 420,
      490, 590, 740, 890, 1090, 1290, 1490, 1740, 1990, 2240, 2490, 2990, 3490, 3990, 1000000 ); 
/* HCP  vs NV  and V */    
 /*   20              0          0
  *   21             50         50
  *   22             70         70
  *   23            110        110
  *   24            200        290
  *   25            300        440
  *   26            350        520
  *   27            400        600
  *   28            430        630
  *   29            460        660
  *   30            490        690
  *   31            600        900
  *   32            700       1050
  *   33            900       1350
  *   34           1000       1500
  *   35           1100       1650
  *   36           1200       1800
  *   37           1300       1950
  *   38           1300       1950
  *   39           1300       1950
  *   40           1300       1950 */
  
  /* index = HCP - 20 */
$russi[1]=array(0, 50, 70, 110, 200, 300, 350, 400, 430, 460, 490, 600,  700,  900, 1000, 1100, 1200, 1300, 1300, 1300, 1300);  
$russi[2]=array(0, 50, 70, 110, 290, 440, 520, 600, 630, 660, 690, 900, 1050, 1350, 1500, 1650, 1800, 1950, 1950, 1950, 1950);

$estonian= array();   
$estonian['8minor'][1]  =array(-20, 30, 60, 80,160,190,320,360,390, 420, 490, 560, 710, 840, 940,1040,1140,1240,1340,1440,1540);
$estonian['8minor'][2]  =array(-40,  0, 50, 80,180,270,440,490,580, 640, 740, 840,1060,1240,1390,1540,1690,1840,1990,2140,2290);
$estonian['9minor'][1]  =array(-40, 20, 60, 90,170,260,340,410,470, 530, 670, 820, 900, 940,1040,1140,1240,1340,1440,1540,1640);
$estonian['9minor'][2]  =array(-60,-10, 70,110,200,400,500,590,680, 770, 990,1210,1330,1390,1540,1690,1840,1990,2140,2290,2440);
$estonian['10minor'][1] =array(-60, 40, 70,160,260,320,420,480,590, 670, 850, 950,1000,1040,1140,1240,1340,1440,1540,1640,1740);
$estonian['10minor'][2] =array(-70, 40,100,260,320,450,560,680,870,1000,1250,1400,1480,1540,1690,1840,1990,2140,2290,2440,2590);

$estonian['8MAJOR'][1]  =array( 30, 60,100,140,190,270,350,400,420, 450, 550, 620, 770, 910,1010,1110,1210,1310,1410,1510,1610);
$estonian['8MAJOR'][2]  =array( 10, 30,100,180,310,410,500,580,630, 660, 770, 900,1120,1310,1460,1610,1760,1910,2060,2210,2360);
$estonian['9MAJOR'][1]  =array( 90,140,170,260,330,390,430,470,540, 600, 730, 890, 970,1010,1110,1210,1310,1410,1510,1610,1710);
$estonian['9MAJOR'][2]  =array( 70,130,200,330,450,550,630,690,750, 860,1050,1280,1400,1460,1610,1760,1910,2060,2210,2360,2510);
$estonian['10MAJOR'][1] =array(120,160,230,280,370,400,440,510,640, 720, 920,1020,1070,1110,1210,1310,1410,1510,1610,1710,1810);
$estonian['10MAJOR'][2] =array(120,240,310,380,510,570,640,730,920,1050,1320,1470,1550,1610,1760,1910,2060,2210,2360,2510,2660);

$estonian['nofit'][1]  =array( 20, 40, 60, 90,160,220,310,390,420, 440, 470, 510, 640, 820, 920,1020,1120,1220,1320,1420,1520);
$estonian['nofit'][2]  =array(-10, 20, 50, 80,150,290,480,580,600, 630, 660, 710, 900,1170,1320,1470,1620,1770,1920,2070,2220);

// =============  bridge functions   
function toHCP ($point, $mode) {  
    switch ($mode) {  
      case 'ZHP':
          return round(($point * 40)/52);
      case 'HP':
          return round(($point * 40)/60);
    default:
          return $point;
      
  }
}


function MPtoIMP($punti) {  
global $puntiIMP;
    $score = abs($punti );
    $imp = 0;
    if ($score >10)
        while ($puntiIMP[$imp] < $score) $imp++;
    if ( $punti > 0) return $imp;
    return -$imp;
  }
                         
  function MPtoRussian($punti, $hcp, $vul){    
     $pntattesi = getTarget ('RMP', $hcp, $vul)  ;
     return  MPtoIMP($punti - $pntattesi); 
  }    
  
  function MPtoEstonian($punti, $hcp, $vul, $fit){    
     $pntattesi = getTarget ('EMP', $hcp, $vul, $fit)  ;
     return  MPtoIMP($punti - $pntattesi); 
  }    
 
                  
  function getTarget ($method, $hcp, $vul = 1, $fit = 'nofit', $nmani=1){  
  global $estonian; 
  global $russi;  
   $pntattesi = 0;    
   $avg = $nmani*20;
   switch ($method) {
       case 'EMP':
// array index are 0...20
        if ($hcp < 20){   
            $pntattesi = - $estonian[$fit][$vul][20-$hcp];   
             } else {     
            $pntattesi = $estonian[$fit][$vul][$hcp - 20];   
                }
      break ;
       case 'RMP':  
// array index are 0...20
        if ($hcp < 20){   
            $pntattesi = - $russi[$vul][20-$hcp];   
             } else {     
            $pntattesi = $russi[$vul][$hcp - 20];   
                }
      break ;         
     case 'GBP':         
// limear
       $pntattesi =   10* round((($hcp - $avg)*20 )/3) ;                
//      break ;
       }  
 return    $pntattesi;       
  }
   
   
  
// clcolo MP
function getMPpoints($vul, $contract, $off, $deltaPrese){  
// $vul: 1|2
// $contract: string like 1F, 1Q, 1C, 1P, 1SA... 7SA
// $off: !|!!
// $deltaPrese ....+2|+1|0|-1|-2...  
global $suit;
$score = 0;   
$declarer_vulnerable = ($vul == 2);   
$contract_doubled    = ($off == '!');
$contract_redoubled  = ($off == '!!');  
$contract_suit       =  substr($contract,1);
$contract_tricks     =  substr($contract,0,1);
               
// input data ERROR          
if((  $contract_tricks + 6 + $deltaPrese) >13) 
     return 0;
if((  $contract_tricks + 6 + $deltaPrese) <0) 
     return 0;

if ($deltaPrese < 0){
// start down
    $down = - $deltaPrese;
  if ( $contract_redoubled) {
        if ($declarer_vulnerable) {
// zona surcontrato  
// 400 (prima) 600 (successive)
          $score = 400 + 600*($down-1);
         } else {
// prima surcontrato                
// 200 (prima) 400 (seconda e terza) 600 (successive)  
          switch ($down){
                case 1: $score = 200;
                        break;
                case 2: $score = 600;
                        break;
                default: 
                        $score = 1000 + 600*($down-3);                                
                 }           
         }   
      return -$score;
        }  // end redoubled  
   if ( $contract_doubled) {
        if ($declarer_vulnerable) {
// zona contrato  
// 200 (prima) 300 (successive)
          $score = 200 + 300*($down-1);
         } else {
// prima contrato                
// 100 (prima) 200 (seconda e terza) 300 (successive)
          switch ($down){
                case 1: $score = 100;
                        break;
                case 2: $score = 300;
                        break;
                default: 
                        $score = 500 + 300*($down-3);                                
                 }           
         }   
      return -$score;
        }  // end doubled  
    
   if ($declarer_vulnerable) {
// zona   
          $score = 100*$down;
         } else {
// prima               
          $score = 50*$down;
         }   
      return -$score;
  } // if ($deltaPrese < 0)
// ============  start positive
// prese del contratto
       switch ($contract_suit){
                case $suit[0]: 
                case $suit[1]: 
                        $score = 20*$contract_tricks;
                        break;
                case $suit[2]: 
                case $suit[3]: 
                        $score = 30*$contract_tricks;
                        break;
                case $suit[4]:  
                        $score = 40 + 30*($contract_tricks -1);
               }
     
      if ($contract_doubled) $score   = $score*2;
      if ($contract_redoubled) $score = $score*4;   
// premi manche e bien-joue'     
        if (($score>= 100) && ($declarer_vulnerable)) $score += 500;
        if (($score>= 100) && (!$declarer_vulnerable))  $score += 300;
        if ($score < 100) $score += 50;
        if ($contract_doubled)   $score += 50;
        if ($contract_redoubled) $score += 100;
// premi slam
        if (($contract_tricks ==  6) && (!$declarer_vulnerable)) $score += 500;
        if (($contract_tricks ==  6) && ($declarer_vulnerable))  $score += 750;
        if (($contract_tricks ==  7) && (!$declarer_vulnerable)) $score += 1000;
        if (($contract_tricks ==  7) && ($declarer_vulnerable))  $score += 1500;
// prese in piu
        if (($contract_doubled)&&   (!$declarer_vulnerable)) $score += 100*$deltaPrese;
        if (($contract_doubled)&&   ($declarer_vulnerable))  $score += 200*$deltaPrese;
        if (($contract_redoubled)&& (!$declarer_vulnerable)) $score += 200*$deltaPrese;
        if (($contract_redoubled)&& ($declarer_vulnerable))  $score += 400*$deltaPrese;

        if ((!$contract_redoubled)& (!$contract_doubled))
               switch ($contract_suit){
                case $suit[0]: 
                case $suit[1]: 
                        $score +=  20*$deltaPrese;
                        break;
                case $suit[2]: 
                case $suit[3]: 
                case $suit[4]: 
                        $score +=  30*$deltaPrese;
               }  
return $score;
}

?>